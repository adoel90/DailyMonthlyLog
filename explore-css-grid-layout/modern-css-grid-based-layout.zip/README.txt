A Pen created at CodePen.io. You can find this one at https://codepen.io/peterxjang/pen/vdLROM.

 